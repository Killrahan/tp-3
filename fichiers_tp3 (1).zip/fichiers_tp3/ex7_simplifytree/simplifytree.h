#ifndef SIMPLIFYTREE_H
#define SIMPLIFYTREE_H

#include "BTree.h"
#include "dict.h"

void simplifyExprTree(BTree *tree, Dict *dict);

#endif
