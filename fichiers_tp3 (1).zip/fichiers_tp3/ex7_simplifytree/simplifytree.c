#include "BTree.h"
#include "token.h"
#include "dict.h"

#include "simplifytree.h"

// Assume well-formed expressions tree

void simplifyExprTree(BTree *tree, Dict *dict)
{
  
}
